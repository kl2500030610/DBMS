import { useState } from 'react';
import './Roles.css';
import { apibaseurl, callApi } from './lib';

function Roles() {

    const [role, setRole] = useState("");
    const [menu, setMenu] = useState("");

    function addRole() {

        const data = {
            role: Date.now(),
            rolename: role
        };

        callApi(
            "POST",
            apibaseurl + "/authservice/addrole",
            data,
            null,
            roleResponse
        );
    }

    function roleResponse(res) {

        alert(res.message);

        setRole("");
    }

    function addMenu() {

        const data = {
            mid: Date.now(),
            menu: menu,
            icon: "default.png"
        };

        callApi(
            "POST",
            apibaseurl + "/authservice/addmenu",
            data,
            null,
            menuResponse
        );
    }

    function menuResponse(res) {

        alert(res.message);

        setMenu("");
    }

    function mapRole(menuId) {

        const data = {
            role: 3,
            mid: menuId
        };

        callApi(
            "POST",
            apibaseurl + "/authservice/maprole",
            data,
            null,
            mapResponse
        );
    }

    function mapResponse(res) {

        alert(res.message);
    }

    return (

        <div className="roles-page">

            <div className="role-box">

                <h3>Roles</h3>

                <div className="role-inputs">

                    <input
                        type="text"
                        placeholder="Enter role"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                    />

                    <button onClick={() => addRole()}>
                        Add Role
                    </button>

                </div>

            </div>

            <div className="role-box">

                <h3>Menu</h3>

                <div className="role-inputs">

                    <input
                        type="text"
                        placeholder="Enter menu"
                        value={menu}
                        onChange={(e) => setMenu(e.target.value)}
                    />

                    <button onClick={() => addMenu()}>
                        Add
                    </button>

                </div>

            </div>

            <div className="role-box">

                <h3>Map Menu with Roles</h3>

                <div className="mapping-section">

                    <button onClick={() => mapRole(1)}>
                        Map Dashboard
                    </button>

                    <button onClick={() => mapRole(2)}>
                        Map My Task
                    </button>

                    <button onClick={() => mapRole(3)}>
                        Map Task Manager
                    </button>

                    <button onClick={() => mapRole(4)}>
                        Map User Manager
                    </button>

                    <button onClick={() => mapRole(5)}>
                        Map My Profile
                    </button>

                    <button onClick={() => mapRole(6)}>
                        Map Role
                    </button>

                </div>

            </div>

        </div>
    );
}

export default Roles;