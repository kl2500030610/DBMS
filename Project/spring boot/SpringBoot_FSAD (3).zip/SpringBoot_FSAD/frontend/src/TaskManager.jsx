import { useEffect, useState } from 'react';
import './TaskManager.css';
import { apibaseurl, callApi } from './lib';

function TaskManager() {

    const [task, setTask] = useState("");
    const [description, setDescription] = useState("");
    const [assigned, setAssigned] = useState("Admin");
    const [selectedTask, setSelectedTask] = useState("");
    const [duedate, setDuedate] = useState("");
    const [taskList, setTaskList] = useState([]);
    const [assignedList, setAssignedList] = useState([]);

    useEffect(() => {
        loadTasks();
    }, []);

    function loadTasks() {
        callApi("GET", apibaseurl + "/authservice/listtasks", null, null, taskResponse);
    }

    function taskResponse(res) {
        setTaskList(res);
        setAssignedList(res.filter(t => t.assigned && t.assigned !== ""));
    }

    function addTask() {
        const data = {
            taskname: task,
            description: description,
            assigned: "",
            status: "Not Started",
            priority: "Medium Priority",
            duedate: "",
            remarks: ""
        };
        callApi("POST", apibaseurl + "/authservice/addtask", data, null, addResponse);
    }

    function addResponse(res) {
        alert(res.message);
        loadTasks();
        setTask("");
        setDescription("");
    }

    function assignTask() {
        const found = taskList.find(t => t.taskname === selectedTask);
        if (!found) return alert("Please select a task");
        const data = {
            taskname: found.taskname,
            description: found.description,
            assigned: assigned,
            status: "Not Started",
            priority: found.priority || "Medium Priority",
            duedate: duedate,
            remarks: found.remarks || ""
        };
        callApi("POST", apibaseurl + "/authservice/addtask", data, null, assignResponse);
    }

    function assignResponse(res) {
        alert(res.message);
        loadTasks();
        setAssigned("Admin");
        setSelectedTask("");
        setDuedate("");
    }

    function deleteTask(id) {
        callApi("POST", apibaseurl + "/authservice/deletetask", { id }, null, deleteResponse);
    }

    function deleteResponse(res) {
        alert(res.message);
        loadTasks();
    }

    const unassigned = taskList.filter(t => !t.assigned || t.assigned === "");
    const assigned2 = taskList.filter(t => t.assigned && t.assigned !== "");

    return (
        <div className="task-page">

            {/* Header */}
            <div className="task-header">
                <div className="task-header-left">
                    <p className="task-label">ADMINISTRATION</p>
                    <h1>Task Manager</h1>
                </div>
                <div className="task-stats">
                    <div className="stat-box">
                        <span className="stat-num">{taskList.length}</span>
                        <span className="stat-label">Tasks</span>
                    </div>
                    <div className="stat-box">
                        <span className="stat-num">{assigned2.length}</span>
                        <span className="stat-label">Assigned</span>
                    </div>
                    <div className="stat-box">
                        <span className="stat-num">{taskList.filter(t => t.status === "Completed").length}</span>
                        <span className="stat-label">Completed</span>
                    </div>
                </div>
            </div>

            {/* Create Task */}
            <div className="tm-card">
                <div className="tm-card-header">
                    <div className="tm-icon blue">T</div>
                    <div>
                        <p className="tm-sub">NEW TASK</p>
                        <h2>Create Task</h2>
                    </div>
                </div>
                <div className="tm-card-body">
                    <label>TASK NAME <span className="required">*</span></label>
                    <input
                        type="text"
                        placeholder="Enter a clear, concise task name"
                        value={task}
                        onChange={(e) => setTask(e.target.value)}
                    />
                    <label>TASK DESCRIPTION</label>
                    <textarea
                        placeholder="Describe what needs to be done..."
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                    />
                    <div className="tm-card-footer">
                        <button className="btn-primary" onClick={() => addTask()}>+ Add Task</button>
                    </div>
                </div>
            </div>

            {/* Assign Task */}
            <div className="tm-card">
                <div className="tm-card-header">
                    <div className="tm-icon orange">A</div>
                    <div>
                        <p className="tm-sub">ASSIGNMENT</p>
                        <h2>Assign Task to User</h2>
                    </div>
                </div>
                <div className="tm-card-body">
                    <div className="tm-grid-2">
                        <div>
                            <label>USER <span className="required">*</span></label>
                            <select value={assigned} onChange={(e) => setAssigned(e.target.value)}>
                                <option value="">Select user</option>
                                <option>Admin</option>
                                <option>Manager</option>
                                <option>User</option>
                            </select>
                        </div>
                        <div>
                            <label>TASK <span className="required">*</span></label>
                            <select value={selectedTask} onChange={(e) => setSelectedTask(e.target.value)}>
                                <option value="">Select task</option>
                                {taskList.map(t => (
                                    <option key={t.id} value={t.taskname}>{t.taskname}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                    <div className="tm-grid-2">
                        <div>
                            <label>DUE DATE <span className="required">*</span></label>
                            <input
                                type="date"
                                value={duedate}
                                onChange={(e) => setDuedate(e.target.value)}
                            />
                        </div>
                        <div className="assign-action">
                            <button className="btn-assign" onClick={() => assignTask()}>
                                ➤ Assign
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* All Tasks */}
            <div className="tm-card">
                <div className="tm-card-header">
                    <div>
                        <p className="tm-sub">TASK LIBRARY</p>
                        <h2>All Tasks</h2>
                    </div>
                </div>
                <table className="tm-table">
                    <thead>
                        <tr>
                            <th>S.NO</th>
                            <th>TASK NAME</th>
                            <th>DESCRIPTION</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        {taskList.length === 0 && (
                            <tr><td colSpan="4" className="empty-msg">No tasks yet</td></tr>
                        )}
                        {taskList.map((t, i) => (
                            <tr key={t.id}>
                                <td>{i + 1}</td>
                                <td>{t.taskname}</td>
                                <td>{t.description}</td>
                                <td>
                                    <button className="btn-delete" onClick={() => deleteTask(t.id)}>🗑</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Assigned Tasks */}
            <div className="tm-card">
                <div className="tm-card-header">
                    <div>
                        <p className="tm-sub">ASSIGNMENTS</p>
                        <h2>Assigned Tasks</h2>
                    </div>
                </div>
                <table className="tm-table">
                    <thead>
                        <tr>
                            <th>S.NO</th>
                            <th>USER</th>
                            <th>TASK</th>
                            <th>DESCRIPTION</th>
                            <th>DUE DATE</th>
                            <th>STATUS</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        {assigned2.length === 0 && (
                            <tr><td colSpan="7" className="empty-msg">No assigned tasks</td></tr>
                        )}
                        {assigned2.map((t, i) => (
                            <tr key={t.id}>
                                <td>{i + 1}</td>
                                <td>{t.assigned}</td>
                                <td>{t.taskname}</td>
                                <td>{t.description}</td>
                                <td>{t.duedate}</td>
                                <td><span className="status-badge">{t.status}</span></td>
                                <td>
                                    <button className="btn-delete" onClick={() => deleteTask(t.id)}>🗑</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

        </div>
    );
}

export default TaskManager;